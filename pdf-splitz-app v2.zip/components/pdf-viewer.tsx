"use client"

import { useState } from "react"
import { Download, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"

interface PDFPage {
  pageNumber: number
  pdfBlob: Blob
  previewUrl?: string
}

interface PDFViewerProps {
  pages: PDFPage[]
  fileName: string
  onReset: () => void
}

const pageColors = [
  "from-violet-400 to-purple-500",
  "from-blue-400 to-cyan-500",
  "from-emerald-400 to-teal-500",
  "from-amber-400 to-orange-500",
  "from-pink-400 to-rose-500",
  "from-indigo-400 to-blue-500",
]

export function PDFViewer({ pages, fileName, onReset }: PDFViewerProps) {
  const [downloading, setDownloading] = useState(false)

  const downloadPage = (pageNum: number) => {
    const page = pages.find((p) => p.pageNumber === pageNum)
    if (!page) return

    const url = window.URL.createObjectURL(page.pdfBlob)
    const a = document.createElement("a")
    a.href = url
    const baseName = fileName.replace(/\.pdf$/i, "")
    a.download = `${baseName} page ${pageNum}.pdf`
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  const downloadAll = async () => {
    setDownloading(true)
    for (let i = 1; i <= pages.length; i++) {
      downloadPage(i)
      await new Promise((resolve) => setTimeout(resolve, 300))
    }
    setDownloading(false)
  }

  const openPageInNewTab = (page: PDFPage) => {
    const url = window.URL.createObjectURL(page.pdfBlob)
    window.open(url, "_blank")

    // Clean up the blob URL after a delay
    setTimeout(() => window.URL.revokeObjectURL(url), 1000)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-violet-50 via-background to-blue-50 dark:from-background dark:via-background dark:to-background">
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-blue-600 bg-clip-text text-transparent text-balance">
                {fileName.replace(".pdf", "")}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                {pages.length} page{pages.length !== 1 ? "s" : ""} split successfully
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={downloadAll} disabled={downloading} variant="default" className="gap-2">
                {downloading ? <Spinner size="sm" /> : <Download size={16} />}
                <span className="hidden sm:inline">{downloading ? "Downloading..." : "Download All"}</span>
              </Button>
              <Button onClick={onReset} disabled={downloading} variant="outline" className="gap-2 bg-transparent">
                <RotateCcw size={16} />
                <span className="hidden sm:inline">New PDF</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <p className="text-center text-muted-foreground mb-6 text-sm">
          Click on any page to open it in a new tab, or use the download buttons below each page
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {pages.map((page) => {
            const colorIndex = (page.pageNumber - 1) % pageColors.length
            const gradient = pageColors[colorIndex]

            return (
              <div
                key={page.pageNumber}
                className="bg-card border border-border rounded-lg overflow-hidden shadow-sm hover:shadow-lg hover:scale-[1.02] transition-all"
              >
                <div
                  className="cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => openPageInNewTab(page)}
                  title="Click to open in new tab"
                >
                  {page.previewUrl ? (
                    <div className="aspect-[8.5/11] relative overflow-hidden bg-white">
                      <img
                        src={page.previewUrl || "/placeholder.svg"}
                        alt={`Page ${page.pageNumber} preview`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2 bg-white/90 dark:bg-black/50 backdrop-blur-sm text-foreground text-xs font-bold px-2 py-1 rounded">
                        {page.pageNumber}
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/20">
                        <div className="bg-white rounded-full p-3 shadow-lg">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                            <polyline points="15 3 21 3 21 9"></polyline>
                            <line x1="10" y1="14" x2="21" y2="3"></line>
                          </svg>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className={`aspect-[8.5/11] bg-gradient-to-br ${gradient} relative overflow-hidden`}>
                      <div className="absolute inset-0 bg-white/20 backdrop-blur-[2px]" />
                      <div className="absolute inset-0 flex flex-col justify-center items-center p-4 gap-2">
                        <div className="w-full h-1.5 bg-white/40 rounded" />
                        <div className="w-3/4 h-1.5 bg-white/40 rounded" />
                        <div className="w-full h-1.5 bg-white/40 rounded" />
                        <div className="w-2/3 h-1.5 bg-white/40 rounded" />
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-white text-3xl font-bold drop-shadow-lg">Ready!</span>
                      </div>
                      <div className="absolute top-2 right-2 bg-white/90 dark:bg-black/50 backdrop-blur-sm text-foreground text-xs font-bold px-2 py-1 rounded">
                        {page.pageNumber}
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/20">
                        <div className="bg-white rounded-full p-3 shadow-lg">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                            <polyline points="15 3 21 3 21 9"></polyline>
                            <line x1="10" y1="14" x2="21" y2="3"></line>
                          </svg>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-3">
                  <Button
                    onClick={() => downloadPage(page.pageNumber)}
                    disabled={downloading}
                    size="sm"
                    className="w-full gap-2"
                    variant="outline"
                  >
                    <Download size={14} />
                    Page {page.pageNumber}
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </main>
  )
}
